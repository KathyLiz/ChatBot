
//var con = new ws_miMovistar();
const FACEBOOK_ACCESS_TOKEN = 'EAAFr75mEwRIBAGRZCYFZBeaKNaGnbaSihKhYKaZBBdGJaZCzmCd1qLw647P67LTKeicVTar2o1q4ZAdPwZCGciEXIZBfxbMxlBZBqmzPyOiEUZAPcZBZBd2m514wIZBhRDx7BTM7YkQXW7SFw3lRg3PIZB3AXPzV1og3fdHlJnhcxhy0NGAZDZD';
const API_AI_TOKEN = 'cdcf945552d748d8926c128029130e1c';
const apiAiClient = require('apiai')(API_AI_TOKEN);
const usuario='{"args":{"documentoID":"984057918","clave":"qwe123","perfilUsuario":"Numero"},"session":{"imei":"1234567890","version":"2.2.28","id_session":0},"funcion":"IMOVISTAR_LOGIN"}';
const objetoUsuario =JSON.parse(usuario);
const wsM = require('./ws_miMovistarNode.js');

var FBMessenger = require('fb-messenger');
var messenger = new FBMessenger('EAAFr75mEwRIBAFsodBiKzQ9kfhqkRDOZBhx8QYaGsbBbsmbbFoH6fFYFtrK2qXEsw9cgusPvoLDna6NpUByjGLiIOyaDjbVde9x0Qsm0E9l8m7YZAvUZBwNYINfk4ZB7pmR7ZADBLQFIfNrEKBbBxHZAnS4XJZC5fljl1W8OH9YzAZDZD');

const request = require('request');

var celular1;

//messenger.sendTextMessage(<ID>, 'Hello') // Send a message with NO_PUSH, no callback

// Send an image overriding default notification type with callback

const sendTextMessage = (senderId, text) => {
	var text1 = text;
   request({
        url: 'https://graph.facebook.com/v2.6/me/messages',
        qs: { access_token: FACEBOOK_ACCESS_TOKEN },
        method: 'POST',
        json: {
            recipient: {id: senderId },
			message: {text: text1},
            
        }
    });
};

function sendQuickReplay (senderId){
	return request({
        url: 'https://graph.facebook.com/v2.6/me/messages',
        qs: { access_token: FACEBOOK_ACCESS_TOKEN },
        method: 'POST',
        json: {
            recipient: { id: senderId },
            message: 
				[ { type: 0, speech: 'Su saldo es:' },
				{ title: 'Nos ayudaría con una encuesta, por favor?',
				  replies: [ 'Sí,claro', 'No por el momento' ],
				 type: 2 } ]
        }
    });	
};

//FUNCIÓN DE SALUDO
	function createGreetingApi(data) {
		request({
		uri: 'https://graph.facebook.com/v2.6/me/thread_settings',
		qs: { access_token: PAGE_ACCESS_TOKEN },
		method: 'POST',
		json: data

		}, function (error, response, body) {
		if (!error && response.statusCode == 200) {
		  console.log("Greeting set successfully!");
		} else {
		  console.error("Failed calling Thread Reference API", response.statusCode,     response.statusMessage, body.error);
		}
		});  
		};

		
const checkWhiteList = (senderId) => {
   request({
        url: 'https://graph.facebook.com/v2.6/me/messenger_profile',
        qs: { access_token: FACEBOOK_ACCESS_TOKEN },
        method: 'POST',
        json: {
				"setting_type": "domain_whitelisting",
				"whitelisted_domains": ["https://e84ea710.ngrok.io"],
				"domain_action_type": "add"
			}
    });
};


const sendBeginButton = (senderId) => {
   request({
        url: 'https://graph.facebook.com/v2.6/me/thread_settings',
        qs: { access_token: FACEBOOK_ACCESS_TOKEN },
        method: 'POST',
        json: {
				 "setting_type":"call_to_actions",
				 "thread_state":"new_thread",
				 "call_to_actions":[
				{
				  "payload":"getStarted"
				}
				]
			}
		
    });
};

const buttons= [{"type":"account_link",
					"url": "https://e84ea710.ngrok.io"}];
				
module.exports = (event, login, celular) => {
	celular1 = celular;
	const senderId = event.sender.id;
 	checkWhiteList(senderId);
	
	if(event.message.text)
	{
		const message = event.message.text;
		const apiaiSession = apiAiClient.textRequest(message, {sessionId: 'botcube_co'});
		apiaiSession.on('response', (response) => {
			const roberto = response.result.fulfillment.speech;		
			 //sendTextMessage(senderId,"Hola");	
			 
			if (response.result.action === 'saludo'){
				 //Botón de vinculación de cuentas
				//var mensaje = "Por favor accede con tu número y contraseña Movistar";
				messenger.sendButtonsMessage(senderId,roberto,buttons, 'REGULAR', function (err, body) {
				if (err) return console.error(err)
				});
			 }
			 else if (response.result.action === 'saldo'&& login === true){
						MAD_CONSULTA_SALDO(function (aws) {
						var kathy="";
						if(aws.Controles[0].Data.saldo_plan===""){
							kathy ="\nNo tienes un plan Movistar activado";
						} else {
							kathy="\nPlan: "+aws.Controles[0].Data.saldo_plan;
						}				
						var resultBot5 = roberto + "\n"+aws.Controles[0].Data.saldo_recarga + kathy; 
						sendTextMessage(senderId, resultBot5);			
					});
				
				
			 }else {
				 sendTextMessage(senderId,"Lo siento :( ... Necesitas estar logueado para acceder a las opciones");
			 }
			 //console.log ("Session de api.ai: ",apiaiSession.request.agent._events.free); 
		 });	 
		 apiaiSession.end();
	
	}

	console.log(">el login-->",celular1);
 
};

function MAD_CONSULTA_SALDO(catcher){
	var con = new wsM();
		con.setAccion('IMOVISTAR_DATOS_LINEA');
		var arg = {};
		arg.linea=celular1;		
		arg.keyid="all";
		console.log('Argumentos',arg);
		var session = {};
		session.imei="1234567890";
		session.version="2.2.28";
		session.id_session="0";
		console.log ('Session: ',session);
		con.setArgumentos(arg);
		con.setSession(session);
		con.servicio();
		
		con.setOnExito (catcher);
		con.setOnError (catcher);	
};







